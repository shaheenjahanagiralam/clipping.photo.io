<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Visiovista &lsaquo; Log In</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='http://visiovista.com/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.7.13'></script>
<script type='text/javascript' src='http://visiovista.com/wp-content/plugins/testimonial-add/owl-carousel/owl.carousel.js?ver=4.7.13'></script>
<link rel='stylesheet' href='http://visiovista.com/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='mpsp-custom-style-css'  href='http://visiovista.com/wp-content/plugins/testimonial-add/css/custom_style.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='mpsp-style-css'  href='http://visiovista.com/wp-content/plugins/testimonial-add/owl-carousel/owl.carousel.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='mpsp_theme-css'  href='http://visiovista.com/wp-content/plugins/testimonial-add/owl-carousel/owl.theme.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='mpsp_transitions-css'  href='http://visiovista.com/wp-content/plugins/testimonial-add/owl-carousel/owl.transitions.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='gglcptch-css'  href='http://visiovista.com/wp-content/plugins/google-captcha/css/gglcptch.css?ver=1.29' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Visiovista</a></h1>
	
<form name="loginform" id="loginform" action="http://visiovista.com/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
				<style type="text/css" media="screen">
				.login-action-login #loginform,
				.login-action-lostpassword #lostpasswordform,
				.login-action-register #registerform {
					width: 302px !important;
				}
				#login_error,
				.message {
					width: 322px !important;
				}
				.login-action-login #loginform .gglcptch,
				.login-action-lostpassword #lostpasswordform .gglcptch,
				.login-action-register #registerform .gglcptch {
					margin-bottom: 10px;
				}
			</style>
		<div class="gglcptch gglcptch_v2"><div id="gglcptch_recaptcha_485002653" class="gglcptch_recaptcha"></div>
				<noscript>
					<div style="width: 302px;">
						<div style="width: 302px; height: 422px; position: relative;">
							<div style="width: 302px; height: 422px; position: absolute;">
								<iframe src="https://www.google.com/recaptcha/api/fallback?k=6LcHaR0UAAAAAOMBttWQ1pv_Y1zbPuKnuVGtnV0_" frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;"></iframe>
							</div>
						</div>
						<div style="border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px; height: 60px; width: 300px;">
							<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px !important; height: 40px !important; border: 1px solid #c1c1c1 !important; margin: 10px 25px !important; padding: 0px !important; resize: none !important;"></textarea>
						</div>
					</div>
				</noscript></div>	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="http://visiovista.com/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="http://visiovista.com/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://visiovista.com/">&larr; Back to Visiovista</a></p>
	
	</div>

	
	<script type='text/javascript'>
/* <![CDATA[ */
var gglcptch_pre = {"messages":{"in_progress":"Please wait until Google reCAPTCHA is loaded.","timeout":"Failed to load Google reCAPTCHA. Please check your internet connection and reload this page."}};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var gglcptch = {"options":{"version":"v2","sitekey":"6LcHaR0UAAAAAOMBttWQ1pv_Y1zbPuKnuVGtnV0_","theme":"light","error":"<strong>Warning<\/strong>:&nbsp;More than one reCAPTCHA has been found in the current form. Please remove all unnecessary reCAPTCHA fields to make it work properly."},"vars":{"ajaxurl":"http:\/\/visiovista.com\/wp-admin\/admin-ajax.php","error_msg":"Error:&nbsp;You have entered an incorrect reCAPTCHA value.","nonce":"3ece7adccc","visibility":true,"excluded_forms":""}};
/* ]]> */
</script>
<script type='text/javascript' src='http://visiovista.com/wp-content/plugins/google-captcha/js/pre-api-script.js?ver=1.29'></script>
<script type='text/javascript' data-cfasync="false" async="async" defer="defer" src='https://www.google.com/recaptcha/api.js?onload=gglcptch_onload_callback&#038;render=explicit&#038;ver=1.29'></script>
<script type='text/javascript' src='http://visiovista.com/wp-content/plugins/google-captcha/js/script.js?ver=1.29'></script>
	<div class="clear"></div>
	</body>
	</html>
	<!-- wp-login.php -->